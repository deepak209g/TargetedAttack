from __future__ import absolute_import, division, print_function, unicode_literals

from eml_parser.eml_parser import decode_email_s, decode_email
