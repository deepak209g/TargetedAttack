﻿Credits
=======

``eml_parser`` is written and maintained by `Georges Toth <https://github.com/sim0nx>`_.

Contributors
------------

The following people contributed directly or indirectly to this project:

- `Sławomir Zborowski <https://github.com/szborows>`_
- `Gregor Aisch <https://github.com/gka>`_
- Paul Jung
