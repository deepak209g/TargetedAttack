.. _api:

API Documentation
=================

eml_parser
----------

.. automodule:: eml_parser.eml_parser
    :members:

